<?php

$JSONsosit=file_get_contents("php://input");
$FormatSosit=$_SERVER["CONTENT_TYPE"];

$cerere=curl_init();

$configurari=[CURLOPT_RETURNTRANSFER=>1,
			CURLOPT_URL=>"http://site2.com/sursacurlpost.php",
			CURLOPT_POST=>1,
			CURLOPT_HTTPHEADER=>["Content-type"=>$FormatSosit],
			CURLOPT_POSTFIELDS=>$JSONsosit];

curl_setopt_array($cerere,$configurari);
$rezultat=curl_exec($cerere);

print $rezultat;
curl_close($cerere);
?>