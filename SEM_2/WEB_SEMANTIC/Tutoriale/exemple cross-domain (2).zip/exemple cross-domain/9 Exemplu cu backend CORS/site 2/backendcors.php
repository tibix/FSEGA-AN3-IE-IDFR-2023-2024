<?php
header("Access-Control-Allow-Origin: *");
// in loc de * putem indica serverele de la care se accepta cereri

/*
cu * serverul accepta cereri cu orice origine dar ...
cu IF-urile de jos face verificari asupra cererii
pentru a decide ce se accepta cu adevarat
*/

if ($_SERVER["REQUEST_METHOD"]=="OPTIONS")
	{
	header("Access-Control-Allow-Methods: OPTIONS,POST");
	header("Access-Control-Allow-Headers: Content-Type");
    header('Access-Control-Max-Age: 0');
	}
/*
mai intai verificam daca e vorba de pre-cerere (pre-flighted)
ca raspuns, browserul e informat ce fel de cereri
poate trimite
*/
elseif ($_SERVER["REQUEST_METHOD"]=="POST")
	{
	if (($_SERVER["HTTP_ORIGIN"]=="http://site1.com")&&($_SERVER["CONTENT_TYPE"]=="application/json"))
		{
		$dateClient=file_get_contents("php://input");
		$datePHP=json_decode($dateClient);
		print "Serverul confirma primirea de note pentru ".$datePHP[0]->Nume." si ".$datePHP[1]->Nume;
		}
	elseif ($_SERVER["CONTENT_TYPE"]!="application/json") 
		{
		print "Nu accept cereri care nu-mi trimit JSON!";
		}
	elseif ($_SERVER["HTTP_ORIGIN"]!="http://site1.com")
		{
		print "Nu accept cereri decat de la site1.com!";
		//chiar daca pe prima linie am declarat ca accept orice origine!
		//filtrarea dupa origine poate combina antentul ACAO cu un astfel de IF
		}
	}
else print "Nu accept cereri GET!";
/*
in al doilea IF se verifica cererea propriu-zisa
testand diverse aspecte ale cererii, disponibile in $_SERVER
- se accepta doar cereri POST
- se accepta doar cereri de la site1.com
- se accepta doar cereri care vin cu date JSON
*/
?>