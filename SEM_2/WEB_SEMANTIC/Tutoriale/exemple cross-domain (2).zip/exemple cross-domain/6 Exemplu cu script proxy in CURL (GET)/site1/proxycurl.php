<?php
header("Content-type:application/json");
$cerere=curl_init();

$configurari=array(CURLOPT_RETURNTRANSFER=>1,CURLOPT_URL=>"http://site2.com/sursacurlget.php");
curl_setopt_array($cerere,$configurari);
$rezultat=curl_exec($cerere);

print $rezultat;
curl_close($cerere);
?>