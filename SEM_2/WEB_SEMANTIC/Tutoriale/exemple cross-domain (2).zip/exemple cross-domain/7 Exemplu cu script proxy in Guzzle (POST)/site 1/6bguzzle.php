<?php
require "vendor/autoload.php";
$client=new \GuzzleHttp\Client();

$JSONsosit=file_get_contents("php://input");
$FormatSosit=$_SERVER["CONTENT_TYPE"];

$configurari=["body"=>$JSONsosit,"headers"=>["Content-Type"=>$FormatSosit]];


$cerere=$client->postAsync("http://site2.com/8datejsonpost.php",$configurari);
$cerere->then("procesareRaspuns")->wait();

function procesareRaspuns($raspuns)
	{
	print $raspuns->getBody();
	}
?>
