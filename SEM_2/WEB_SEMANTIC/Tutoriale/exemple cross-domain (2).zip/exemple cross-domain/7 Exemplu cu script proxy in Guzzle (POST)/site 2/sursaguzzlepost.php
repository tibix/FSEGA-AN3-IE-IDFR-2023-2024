<?php
$Produs1=["ID"=>"P1","Pret"=>100,"Denumire"=>"Televizor"];
$Produs2=["ID"=>"P2","Pret"=>30,"Denumire"=>"Ipod"];
$Produse=[$Produs1,$Produs2];
//presupunem ca avem datele in acest array

$JSONsosit=file_get_contents("php://input");
$dateSosite=json_decode($JSONsosit);
$IDfromProxy=$dateSosite->identificator;
//am receptionat ID-ul forwardat de proxy
//il preluam din php://input caci $_POST se poate folosi doar pentru QueryString/FormData

$pozitie=array_search($IDfromProxy, array_column($Produse,"ID"));
//array_column extrage un camp din obiectele unui array (aici campul ID)
//si formeaza un array doar cu acel camp
//array_search cauta o valoare intr-un array si returneaza pozitia
//impreuna, cele doua functii obtin pozitia in $Produse a produsului cu ID-ul cautat

$denumire=$Produse[$pozitie]["Denumire"];

print $denumire;
?>