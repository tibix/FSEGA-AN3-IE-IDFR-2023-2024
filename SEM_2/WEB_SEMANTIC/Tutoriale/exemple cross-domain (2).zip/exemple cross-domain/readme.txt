Toate aceste exemple presupune rularea a doua servere fictive (virtual hosts),
cu adresele site1.com si site2.com.

La inceputul tutorialului PDF e prezentata configurarea acestora pentru XAMPP
in Windows.