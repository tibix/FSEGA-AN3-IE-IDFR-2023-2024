<?php
require "vendor/autoload.php";
header("Content-type:application/json");

$client=new \GuzzleHttp\Client();
$cerere=$client->getAsync("http://site2.com/sursaguzzleget.php");
$cerere->then("procesareRaspuns")->wait();

function procesareRaspuns($raspuns)
	{
	print $raspuns->getBody();
	}
?>
