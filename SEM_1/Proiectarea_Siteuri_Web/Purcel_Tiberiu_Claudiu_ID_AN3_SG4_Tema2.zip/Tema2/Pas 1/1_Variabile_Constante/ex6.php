<html>
<head><title>Exemplu variabile PHP </title></head>
<body>
<h2> Numele de variabile sunt case senzitive</h2>
<?php
$nume = "Aici se memorează un text";
$Nume = "Aici se memorează un alt text";
echo $nume;
echo "<p/>";
echo $Nume;
?>
</body>
</html>