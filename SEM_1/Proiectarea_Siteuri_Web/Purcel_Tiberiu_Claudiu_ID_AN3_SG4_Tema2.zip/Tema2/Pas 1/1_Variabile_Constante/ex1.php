<html>
<head>
    <title>Exemplu pentru toatea tipurile de variabile PHP</title>
</head>
<body>
        <pre>
            <?php echo "Hello\n world\t"; ?>
        </pre>

        <?php echo "El sa spus: \"Ai nevoie de chestiile astea!\" pentru studenti"; ?>
</body>
</html>