<html>
<body>
<?php
$p = "POP";
$l = "VIOREL";
$spatiu = ($p . " "); // concatenare!
$nume = ($spatiu . $l); // concatenatre!
echo "<h1>$nume</h1>";
?>
</body>
</html>