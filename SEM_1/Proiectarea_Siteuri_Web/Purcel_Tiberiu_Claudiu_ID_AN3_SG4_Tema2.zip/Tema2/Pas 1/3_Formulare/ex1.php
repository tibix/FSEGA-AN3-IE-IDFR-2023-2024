<html>
<head>
    <title> Formular cu GET</title></head>
<body>
<form action="ex1.php" method="get">
    Nume: <input type="text" name="nume"/>
    Varsta: <input type="text" name="varsta"/>
    <input type="submit"/>
</form>
</body>
</html>