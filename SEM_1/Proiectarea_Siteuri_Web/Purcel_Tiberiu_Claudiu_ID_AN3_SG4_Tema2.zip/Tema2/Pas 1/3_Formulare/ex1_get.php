<?php
echo "Bun venit," . $_GET["nume"] . "<br/>";
echo "Varsta dvs," . $_GET["varsta"] . "!";
