<html>
<head>
    <title> Determinarea minimului dintre doua valori </title>
</head>
<body>
<?php
//Determinarea minimului dintre doua valori
$a = 10;
$b = 7;
if ($a < $b) {
    echo "Minimul este:$a";
} else {
    echo "Minimul este:$b";
}
?>
</body>
</html>